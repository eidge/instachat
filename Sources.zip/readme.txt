InstaChat is experimental unfinished software. 

This software is being made with the sole purpose of learning, my c++ skills are not spectacular, as there subjects that I'm just now touching like inheritance and virtual functions and other that I haven't even touched like templates.

If you want to test this program alone, open two instances of the software. Run one using the server option and another with the connect option. In the ip field enter: "localhost" (without the quotation marks).

Please report any bugs you find, you didn't find any and you still have something to say? Do it, then. Feedback is very much welcome.

Current Problems: 
The keyboard map was made using my own layout so people using a keyboard that is not portuguese might experience problems.
Host Blocks untila client connection is successful.